import React, { useState } from 'react';
import { TopNav } from '../components/TopNav';
import { FilterBar, Filter } from '../components/FilterBar';
import { MetricCard } from '../components/MetricCard';
import { Card } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { TierTag, TierType } from '../components/TierTag';
import { Switch } from '../components/ui/switch';
import { Label } from '../components/ui/label';
import { Users, Clock, DollarSign, TrendingUp, AlertCircle, ChevronRight } from 'lucide-react';
import { mockFlights } from '../lib/mockData';
import { toast } from 'sonner@2.0.3';

interface IOCQueuesProps {
  onNavigateToCohort?: (flightNumber: string) => void;
}

export function IOCQueues({ onNavigateToCohort }: IOCQueuesProps) {
  const [station, setStation] = useState('HKG');
  const [protectPremium, setProtectPremium] = useState(true);
  const [selectedFlights, setSelectedFlights] = useState<string[]>([]);

  const filters: Filter[] = [
    {
      id: 'station',
      label: 'Station',
      type: 'select',
      options: [
        { label: 'Hong Kong (HKG)', value: 'HKG' },
        { label: 'Los Angeles (LAX)', value: 'LAX' },
        { label: 'London (LHR)', value: 'LHR' },
        { label: 'San Francisco (SFO)', value: 'SFO' },
      ],
      value: station,
      onValueChange: setStation,
    },
    {
      id: 'severity',
      label: 'Severity',
      type: 'select',
      options: [
        { label: 'All', value: 'all' },
        { label: 'High', value: 'high' },
        { label: 'Medium', value: 'medium' },
        { label: 'Low', value: 'low' },
      ],
    },
    {
      id: 'cabin',
      label: 'Cabin',
      type: 'select',
      options: [
        { label: 'All Cabins', value: 'all' },
        { label: 'First (F)', value: 'F' },
        { label: 'Business (J)', value: 'J' },
        { label: 'Premium Economy (W)', value: 'W' },
        { label: 'Economy (Y)', value: 'Y' },
      ],
    },
  ];

  const handleBulkAction = (action: string) => {
    if (selectedFlights.length === 0) {
      toast.error('No flights selected');
      return;
    }
    toast.success(`${action} applied to ${selectedFlights.length} flight(s)`);
    setSelectedFlights([]);
  };

  const toggleFlightSelection = (flightNumber: string) => {
    setSelectedFlights((prev) =>
      prev.includes(flightNumber)
        ? prev.filter((f) => f !== flightNumber)
        : [...prev, flightNumber]
    );
  };

  return (
    <div className="min-h-screen bg-[#EBEDEC]">
      <TopNav 
        title="IROP Recovery Dashboard" 
        subtitle="Integrated Operations Center"
        actions={
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <Switch 
                id="protect-premium" 
                checked={protectPremium}
                onCheckedChange={setProtectPremium}
              />
              <Label htmlFor="protect-premium" className="text-[14px] cursor-pointer">
                Protect premium inventory
              </Label>
            </div>
          </div>
        }
      />
      
      <FilterBar filters={filters} />

      <div className="p-8">
        {/* Metrics */}
        <div className="grid grid-cols-4 gap-6 mb-8">
          <MetricCard
            label="Auto-reaccommodated"
            value="87%"
            icon={Users}
            trend="+5% vs last event"
            trendUp={true}
          />
          <MetricCard
            label="Median time-to-plan"
            value="3.2m"
            icon={Clock}
            trend="-0.8m improvement"
            trendUp={true}
          />
          <MetricCard
            label="Premium revenue protected"
            value="$2.4M"
            icon={DollarSign}
            trend="+12% vs baseline"
            trendUp={true}
          />
          <MetricCard
            label="Voucher cost/pax"
            value="$142"
            icon={TrendingUp}
            trend="-$18 vs avg"
            trendUp={true}
          />
        </div>

        {/* Flight Queue List */}
        <div className="space-y-4">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-[18px] leading-[24px] font-semibold">Affected Flights</h2>
            {selectedFlights.length > 0 && (
              <div className="flex items-center gap-3">
                <span className="text-[14px] text-muted-foreground">
                  {selectedFlights.length} selected
                </span>
                <Button 
                  size="sm" 
                  variant="outline"
                  onClick={() => handleBulkAction('Default options applied')}
                >
                  Apply Default
                </Button>
                <Button 
                  size="sm" 
                  variant="outline"
                  onClick={() => handleBulkAction('Offers sent')}
                >
                  Send Offers
                </Button>
                <Button 
                  size="sm"
                  onClick={() => handleBulkAction('Cohort opened')}
                >
                  Open Cohort
                </Button>
              </div>
            )}
          </div>

          {mockFlights.map((flight) => (
            <Card 
              key={flight.flightNumber}
              className={`p-6 rounded-[12px] transition-all cursor-pointer ${
                selectedFlights.includes(flight.flightNumber) ? 'ring-2 ring-primary' : ''
              }`}
              onClick={() => toggleFlightSelection(flight.flightNumber)}
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-4 mb-4">
                    <h3 className="text-[20px] font-semibold">{flight.flightNumber}</h3>
                    <span className="text-[16px] text-muted-foreground">{flight.route}</span>
                    <Badge 
                      variant={flight.severity === 'High' ? 'destructive' : 'secondary'}
                      className="text-[12px]"
                    >
                      {flight.severity}
                    </Badge>
                    <span className="text-[14px] text-muted-foreground">
                      {flight.affectedCount} affected
                    </span>
                  </div>

                  <div className="grid grid-cols-3 gap-6">
                    {/* Tier Breakdown */}
                    <div>
                      <h4 className="text-[12px] text-muted-foreground mb-2">By Tier</h4>
                      <div className="flex flex-wrap gap-2">
                        {flight.tierBreakdown.map((item) => (
                          <div key={item.tier} className="flex items-center gap-2">
                            <TierTag tier={item.tier as TierType} />
                            <span className="text-[14px]">{item.count}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Cabin Breakdown */}
                    <div>
                      <h4 className="text-[12px] text-muted-foreground mb-2">By Cabin</h4>
                      <div className="flex flex-wrap gap-2">
                        {flight.cabinBreakdown.map((item) => (
                          <Badge key={item.cabin} variant="outline" className="text-[12px]">
                            {item.cabin}: {item.count}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    {/* Stats */}
                    <div>
                      <h4 className="text-[12px] text-muted-foreground mb-2">Status</h4>
                      <div className="space-y-1 text-[14px]">
                        <div className="flex items-center gap-2">
                          <span className="text-success">✓</span>
                          <span>{flight.defaultSuitability}% default suitable</span>
                        </div>
                        {flight.exceptions > 0 && (
                          <div className="flex items-center gap-2">
                            <AlertCircle className="w-4 h-4 text-destructive" />
                            <span className="text-destructive">{flight.exceptions} exceptions</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>

                <Button
                  variant="ghost"
                  size="sm"
                  onClick={(e) => {
                    e.stopPropagation();
                    onNavigateToCohort?.(flight.flightNumber);
                  }}
                >
                  View Details <ChevronRight className="w-4 h-4 ml-1" />
                </Button>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
