import React, { useState } from 'react';
import { Card } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { TierTag } from '../components/TierTag';
import { OptionCard, Option } from '../components/OptionCard';
import { PolicyCallout } from '../components/PolicyCallout';
import { Badge } from '../components/ui/badge';
import { Separator } from '../components/ui/separator';
import { User, Phone, Mail, Plane, Clock, MapPin, DollarSign } from 'lucide-react';
import { mockPassenger, mockOptions } from '../lib/mockData';
import { toast } from 'sonner@2.0.3';

export function AgentPassengerPanel() {
  const [selectedOption, setSelectedOption] = useState<string>('A');
  const passenger = mockPassenger;
  const options = mockOptions;

  const handleAcceptTicket = () => {
    toast.success(`Re-accommodation accepted for ${passenger.name}`, {
      description: `Option ${selectedOption} has been ticketed`,
    });
  };

  return (
    <div className="min-h-screen bg-[#EBEDEC]">
      <div className="h-16 bg-white border-b border-border flex items-center px-8">
        <h1 className="text-[24px] leading-[32px] font-semibold">Agent Re-accommodation Console</h1>
      </div>

      <div className="flex h-[calc(100vh-64px)]">
        {/* Left Panel - Passenger Summary */}
        <div className="w-[280px] bg-white border-r border-border p-6 overflow-y-auto">
          <Card className="p-4 mb-4 rounded-[12px] bg-primary/5 border-primary/20">
            <div className="flex items-center gap-2 mb-3">
              <User className="w-5 h-5 text-primary" />
              <span className="text-[12px] font-mono text-muted-foreground">PNR: {passenger.pnr}</span>
            </div>
            
            <h3 className="text-[18px] leading-[24px] font-semibold mb-2">{passenger.name}</h3>
            
            <div className="flex items-center gap-2 mb-3">
              <TierTag tier={passenger.tier} />
              <Badge variant="outline" className="text-[12px]">Cabin {passenger.cabin}</Badge>
            </div>
            
            <div className="flex items-center gap-2 text-[14px] mb-2">
              <DollarSign className="w-4 h-4 text-muted-foreground" />
              <span className="text-muted-foreground">Value:</span>
              <span className="font-semibold">${passenger.value.toLocaleString()}</span>
            </div>
          </Card>

          <div className="space-y-4">
            <div>
              <h4 className="text-[14px] font-semibold mb-2">SSRs</h4>
              <div className="flex flex-wrap gap-2">
                {passenger.ssrs.map((ssr) => (
                  <Badge key={ssr} variant="secondary" className="text-[12px]">{ssr}</Badge>
                ))}
              </div>
            </div>

            <Separator />

            <div>
              <h4 className="text-[14px] font-semibold mb-2">Contact</h4>
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-[14px]">
                  <Phone className="w-4 h-4 text-muted-foreground" />
                  <span className="text-[12px]">{passenger.contact}</span>
                </div>
                <div className="flex items-center gap-2 text-[14px]">
                  <Mail className="w-4 h-4 text-muted-foreground" />
                  <span className="text-[12px]">s.mitchell@email.com</span>
                </div>
              </div>
            </div>

            <Separator />

            <div>
              <h4 className="text-[14px] font-semibold mb-3">Original Itinerary</h4>
              <Card className="p-3 rounded-[8px] bg-destructive/5 border-destructive/20">
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-[14px]">
                    <Plane className="w-4 h-4 text-destructive" />
                    <span className="font-semibold text-destructive">{passenger.originalFlight}</span>
                  </div>
                  <div className="flex items-center gap-2 text-[12px] text-muted-foreground">
                    <MapPin className="w-3 h-3" />
                    <span>{passenger.originalRoute}</span>
                  </div>
                  <div className="flex items-center gap-2 text-[12px] text-muted-foreground">
                    <Clock className="w-3 h-3" />
                    <span>Scheduled: {passenger.originalTime}</span>
                  </div>
                  <Badge variant="destructive" className="text-[10px] mt-2">CANCELLED</Badge>
                </div>
              </Card>
            </div>
          </div>
        </div>

        {/* Center Panel - Options */}
        <div className="flex-1 p-8 overflow-y-auto">
          <div className="max-w-[800px] mx-auto space-y-4">
            <h2 className="text-[18px] leading-[24px] font-semibold mb-4">Re-accommodation Options</h2>
            
            {options.map((option) => (
              <OptionCard
                key={option.id}
                {...option}
                optionId={option.id}
                selected={selectedOption === option.id}
                onClick={() => setSelectedOption(option.id)}
              />
            ))}
          </div>
        </div>

        {/* Right Panel - Actions */}
        <div className="w-[320px] bg-white border-l border-border p-6 overflow-y-auto">
          <h3 className="text-[18px] leading-[24px] font-semibold mb-4">Actions</h3>
          
          <div className="space-y-3">
            <Button 
              className="w-full h-12 bg-primary hover:bg-primary/90"
              onClick={handleAcceptTicket}
            >
              Accept & Ticket
            </Button>
            
            <Button variant="outline" className="w-full h-12">
              Swap for Incentive
            </Button>
            
            <Button variant="outline" className="w-full h-12">
              Hold Seat
            </Button>
            
            <Button variant="outline" className="w-full h-12">
              Send Link to Passenger
            </Button>
            
            <Button variant="outline" className="w-full h-12 border-destructive text-destructive hover:bg-destructive/10">
              Escalate
            </Button>
          </div>

          <Separator className="my-6" />

          <div className="space-y-4">
            <PolicyCallout 
              title="Policy Waiver"
              message="Overnight hotel accommodation approved for this disruption. WCHR assistance pre-arranged for new flight."
            />

            <Card className="p-4 rounded-[12px] bg-success/5 border-success/20">
              <h4 className="text-[14px] font-semibold mb-2">Compensation</h4>
              <p className="text-[12px] text-muted-foreground mb-3">
                Diamond tier automatic benefits
              </p>
              <div className="space-y-1 text-[12px]">
                <div className="flex justify-between">
                  <span>Miles credit</span>
                  <span className="font-semibold">15,000</span>
                </div>
                <div className="flex justify-between">
                  <span>Lounge voucher</span>
                  <span className="font-semibold">✓</span>
                </div>
                <div className="flex justify-between">
                  <span>Priority rebooking</span>
                  <span className="font-semibold">✓</span>
                </div>
              </div>
            </Card>
          </div>

          <div className="mt-6 p-4 bg-muted rounded-lg">
            <div className="text-[12px] text-muted-foreground space-y-1">
              <div className="flex justify-between">
                <span>Confidence</span>
                <span className="font-semibold text-foreground">92%</span>
              </div>
              <div className="flex justify-between">
                <span>Inventory Protected</span>
                <span className="font-semibold text-foreground">J/F</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
