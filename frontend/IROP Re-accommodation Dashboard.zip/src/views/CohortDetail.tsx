import React, { useState } from 'react';
import { TopNav } from '../components/TopNav';
import { Button } from '../components/ui/button';
import { Checkbox } from '../components/ui/checkbox';
import { Input } from '../components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../components/ui/table';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from '../components/ui/sheet';
import { TierTag } from '../components/TierTag';
import { OptionCard } from '../components/OptionCard';
import { Badge } from '../components/ui/badge';
import { Separator } from '../components/ui/separator';
import { Pagination, PaginationContent, PaginationItem, PaginationLink, PaginationNext, PaginationPrevious } from '../components/ui/pagination';
import { Search, Download, FileText, AlertTriangle } from 'lucide-react';
import { mockCohortPassengers, mockOptions } from '../lib/mockData';
import { toast } from 'sonner@2.0.3';

interface CohortDetailProps {
  flightNumber?: string;
  onBack?: () => void;
}

export function CohortDetail({ flightNumber = 'CX255', onBack }: CohortDetailProps) {
  const [selectedPassengers, setSelectedPassengers] = useState<string[]>([]);
  const [selectedPnr, setSelectedPnr] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  const passengers = mockCohortPassengers;
  const filteredPassengers = passengers.filter(
    (p) =>
      p.pnr.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const togglePassenger = (pnr: string) => {
    setSelectedPassengers((prev) =>
      prev.includes(pnr) ? prev.filter((p) => p !== pnr) : [...prev, pnr]
    );
  };

  const toggleAll = () => {
    if (selectedPassengers.length === passengers.length) {
      setSelectedPassengers([]);
    } else {
      setSelectedPassengers(passengers.map((p) => p.pnr));
    }
  };

  const handleBulkAccept = () => {
    toast.success(`${selectedPassengers.length} passengers re-accommodated`, {
      description: 'Default options have been ticketed',
    });
    setSelectedPassengers([]);
  };

  const selectedPassenger = passengers.find((p) => p.pnr === selectedPnr);

  return (
    <div className="min-h-screen bg-[#EBEDEC]">
      <TopNav
        title={`Flight ${flightNumber} — ${passengers.length} affected`}
        actions={
          <div className="flex items-center gap-3">
            {onBack && (
              <Button variant="outline" onClick={onBack}>
                ← Back to Queue
              </Button>
            )}
            <Button variant="outline">
              <Download className="w-4 h-4 mr-2" />
              Export CSV
            </Button>
          </div>
        }
      />

      <div className="flex h-[calc(100vh-64px)]">
        {/* Left Panel - Table */}
        <div className="flex-1 flex flex-col bg-white">
          {/* Search Bar */}
          <div className="p-4 border-b border-border">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search by PNR or name..."
                className="pl-10 h-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>

          {/* Table */}
          <div className="flex-1 overflow-auto">
            <Table>
              <TableHeader>
                <TableRow className="h-[44px]">
                  <TableHead className="w-12">
                    <Checkbox
                      checked={selectedPassengers.length === passengers.length}
                      onCheckedChange={toggleAll}
                    />
                  </TableHead>
                  <TableHead>PNR</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Tier</TableHead>
                  <TableHead>Cabin</TableHead>
                  <TableHead>Default Option</TableHead>
                  <TableHead>Confidence</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Notes</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredPassengers.map((passenger) => (
                  <TableRow
                    key={passenger.pnr}
                    className={`h-[44px] cursor-pointer ${
                      selectedPnr === passenger.pnr ? 'bg-primary/5' : ''
                    }`}
                    onClick={() => setSelectedPnr(passenger.pnr)}
                  >
                    <TableCell onClick={(e) => e.stopPropagation()}>
                      <Checkbox
                        checked={selectedPassengers.includes(passenger.pnr)}
                        onCheckedChange={() => togglePassenger(passenger.pnr)}
                      />
                    </TableCell>
                    <TableCell className="font-mono text-[12px]">{passenger.pnr}</TableCell>
                    <TableCell className="text-[14px]">{passenger.name}</TableCell>
                    <TableCell>
                      <TierTag tier={passenger.tier} />
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className="text-[12px]">{passenger.cabin}</Badge>
                    </TableCell>
                    <TableCell className="text-[14px] font-semibold">
                      Option {passenger.defaultOption}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <div className="h-1.5 w-16 bg-muted rounded-full overflow-hidden">
                          <div
                            className={`h-full ${
                              passenger.confidence >= 85
                                ? 'bg-success'
                                : passenger.confidence >= 70
                                ? 'bg-warning'
                                : 'bg-muted-foreground'
                            }`}
                            style={{ width: `${passenger.confidence}%` }}
                          />
                        </div>
                        <span className="text-[12px]">{passenger.confidence}%</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      {passenger.hasException ? (
                        <Badge variant="destructive" className="text-[12px] gap-1">
                          <AlertTriangle className="w-3 h-3" />
                          Exception
                        </Badge>
                      ) : (
                        <Badge variant="outline" className="text-[12px] text-success border-success">
                          Ready
                        </Badge>
                      )}
                    </TableCell>
                    <TableCell className="text-[12px] text-muted-foreground">
                      {passenger.notes || '—'}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {/* Pagination */}
          <div className="h-16 border-t border-border bg-white px-6 flex items-center justify-between">
            {selectedPassengers.length > 0 ? (
              <>
                <span className="text-[14px] text-muted-foreground">
                  {selectedPassengers.length} passenger{selectedPassengers.length !== 1 ? 's' : ''} selected
                </span>
                <div className="flex items-center gap-3">
                  <Button variant="outline" size="sm">
                    <FileText className="w-4 h-4 mr-2" />
                    Add Note
                  </Button>
                  <Button variant="outline" size="sm">
                    Schedule
                  </Button>
                  <Button size="sm" onClick={handleBulkAccept}>
                    Accept Selected
                  </Button>
                </div>
              </>
            ) : (
              <>
                <span className="text-[14px] text-muted-foreground">
                  Showing {filteredPassengers.length} of {passengers.length} passengers
                </span>
                <Pagination>
                  <PaginationContent>
                    <PaginationItem>
                      <PaginationPrevious href="#" />
                    </PaginationItem>
                    <PaginationItem>
                      <PaginationLink href="#" isActive>1</PaginationLink>
                    </PaginationItem>
                    <PaginationItem>
                      <PaginationLink href="#">2</PaginationLink>
                    </PaginationItem>
                    <PaginationItem>
                      <PaginationLink href="#">3</PaginationLink>
                    </PaginationItem>
                    <PaginationItem>
                      <PaginationNext href="#" />
                    </PaginationItem>
                  </PaginationContent>
                </Pagination>
              </>
            )}
          </div>
        </div>

        {/* Right Drawer */}
        <Sheet open={!!selectedPnr} onOpenChange={() => setSelectedPnr(null)}>
          <SheetContent side="right" className="w-[480px] overflow-y-auto">
            {selectedPassenger && (
              <>
                <SheetHeader>
                  <SheetTitle>
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <span className="text-[20px]">{selectedPassenger.name}</span>
                        <TierTag tier={selectedPassenger.tier} />
                      </div>
                      <p className="text-[12px] font-mono text-muted-foreground">
                        PNR: {selectedPassenger.pnr}
                      </p>
                    </div>
                  </SheetTitle>
                  <SheetDescription>
                    Passenger re-accommodation options and details
                  </SheetDescription>
                </SheetHeader>

                <div className="mt-6 space-y-6">
                  <div>
                    <h3 className="text-[14px] font-semibold mb-3">Recommended Option</h3>
                    <OptionCard {...mockOptions[0]} optionId={selectedPassenger.defaultOption} />
                  </div>

                  <Separator />

                  <div>
                    <h3 className="text-[14px] font-semibold mb-3">Alternative Options</h3>
                    <div className="space-y-3">
                      {mockOptions.slice(1).map((option) => (
                        <OptionCard key={option.id} {...option} optionId={option.id} />
                      ))}
                    </div>
                  </div>

                  <Separator />

                  <div>
                    <h3 className="text-[14px] font-semibold mb-3">Actions</h3>
                    <div className="space-y-2">
                      <Button className="w-full h-10">Accept & Ticket</Button>
                      <Button variant="outline" className="w-full h-10">
                        Send Offer to Passenger
                      </Button>
                      <Button variant="outline" className="w-full h-10">
                        Add Note
                      </Button>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-[14px] font-semibold mb-3">Activity Log</h3>
                    <div className="space-y-2 text-[12px]">
                      <div className="p-2 bg-muted rounded">
                        <p className="text-muted-foreground">14:32 — AI analysis complete</p>
                      </div>
                      <div className="p-2 bg-muted rounded">
                        <p className="text-muted-foreground">14:30 — Passenger added to queue</p>
                      </div>
                      <div className="p-2 bg-muted rounded">
                        <p className="text-muted-foreground">14:28 — Flight CX255 cancelled</p>
                      </div>
                    </div>
                  </div>
                </div>
              </>
            )}
          </SheetContent>
        </Sheet>
      </div>
    </div>
  );
}
