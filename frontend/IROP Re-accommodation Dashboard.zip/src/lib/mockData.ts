import { TierType } from '../components/TierTag';
import { WhyReason } from '../components/OptionCard';

export interface Passenger {
  pnr: string;
  name: string;
  tier: TierType;
  cabin: string;
  value: number;
  ssrs: string[];
  contact: string;
  originalFlight: string;
  originalRoute: string;
  originalTime: string;
  isPRM: boolean;
  hasInfant: boolean;
  hasFamily: boolean;
}

export interface Option {
  id: string;
  departureTime: string;
  arrivalTime: string;
  route: string;
  cabin: string;
  seats: number;
  trvScore: number;
  arrivalDelta?: string;
  badges?: ('Greener' | 'Protected' | 'Fastest')[];
  whyReasons: WhyReason[];
}

export interface Flight {
  flightNumber: string;
  route: string;
  affectedCount: number;
  tierBreakdown: { tier: TierType; count: number }[];
  cabinBreakdown: { cabin: string; count: number }[];
  defaultSuitability: number;
  exceptions: number;
  severity: 'High' | 'Medium' | 'Low';
}

export const mockPassenger: Passenger = {
  pnr: 'ABCDE1',
  name: 'Sarah Mitchell',
  tier: 'Diamond',
  cabin: 'J',
  value: 15200,
  ssrs: ['WCHR', 'VGML'],
  contact: '+852 9123 4567',
  originalFlight: 'CX255',
  originalRoute: 'HKG → LHR',
  originalTime: '23:55',
  isPRM: true,
  hasInfant: false,
  hasFamily: false,
};

export const mockOptions: Option[] = [
  {
    id: 'A',
    departureTime: '14:30',
    arrivalTime: '19:45+1',
    route: 'HKG → LHR',
    cabin: 'J',
    seats: 4,
    trvScore: 92,
    arrivalDelta: '+2h earlier',
    badges: ['Protected', 'Fastest'],
    whyReasons: [
      { text: 'Diamond tier prioritized for premium cabin protection', type: 'tier' },
      { text: 'Arrives 2 hours earlier than disrupted flight', type: 'time' },
      { text: 'Wheelchair assistance pre-arranged', type: 'policy' },
      { text: 'Revenue protection: maintains J cabin booking value', type: 'revenue' },
      { text: 'Zero downstream connection risk', type: 'risk' },
    ],
  },
  {
    id: 'B',
    departureTime: '10:15',
    arrivalTime: '15:30+1',
    route: 'HKG → LHR',
    cabin: 'W',
    seats: 12,
    trvScore: 78,
    arrivalDelta: '+6h earlier',
    badges: ['Greener'],
    whyReasons: [
      { text: 'Premium Economy available as downgrade option', type: 'tier' },
      { text: 'Significantly earlier arrival time', type: 'time' },
      { text: 'Lower CO₂ emissions on this route', type: 'policy' },
      { text: 'Compensation bundle: 15k miles + meal voucher', type: 'revenue' },
    ],
  },
  {
    id: 'C',
    departureTime: '22:30',
    arrivalTime: '04:15+2',
    route: 'HKG → LHR',
    cabin: 'Y',
    seats: 38,
    trvScore: 64,
    arrivalDelta: '+4h later',
    badges: [],
    whyReasons: [
      { text: 'Economy cabin with guaranteed seating', type: 'tier' },
      { text: 'Overnight hotel accommodation included', type: 'policy' },
      { text: 'Compensation bundle: 25k miles + upgrade voucher', type: 'revenue' },
      { text: 'High availability (38 seats)', type: 'risk' },
    ],
  },
];

export const mockFlights: Flight[] = [
  {
    flightNumber: 'CX255',
    route: 'HKG → LHR',
    affectedCount: 132,
    tierBreakdown: [
      { tier: 'Diamond', count: 12 },
      { tier: 'Gold', count: 28 },
      { tier: 'Silver', count: 34 },
      { tier: 'Green', count: 58 },
    ],
    cabinBreakdown: [
      { cabin: 'F', count: 8 },
      { cabin: 'J', count: 24 },
      { cabin: 'W', count: 42 },
      { cabin: 'Y', count: 58 },
    ],
    defaultSuitability: 87,
    exceptions: 8,
    severity: 'High',
  },
  {
    flightNumber: 'CX881',
    route: 'LAX → HKG',
    affectedCount: 98,
    tierBreakdown: [
      { tier: 'Diamond', count: 8 },
      { tier: 'Gold', count: 18 },
      { tier: 'Silver', count: 26 },
      { tier: 'Green', count: 46 },
    ],
    cabinBreakdown: [
      { cabin: 'F', count: 4 },
      { cabin: 'J', count: 18 },
      { cabin: 'W', count: 32 },
      { cabin: 'Y', count: 44 },
    ],
    defaultSuitability: 92,
    exceptions: 3,
    severity: 'Medium',
  },
  {
    flightNumber: 'CX700',
    route: 'HKG → SFO',
    affectedCount: 76,
    tierBreakdown: [
      { tier: 'Diamond', count: 6 },
      { tier: 'Gold', count: 14 },
      { tier: 'Silver', count: 20 },
      { tier: 'Green', count: 36 },
    ],
    cabinBreakdown: [
      { cabin: 'F', count: 2 },
      { cabin: 'J', count: 14 },
      { cabin: 'W', count: 26 },
      { cabin: 'Y', count: 34 },
    ],
    defaultSuitability: 78,
    exceptions: 12,
    severity: 'Medium',
  },
];

export interface CohortPassenger {
  pnr: string;
  name: string;
  tier: TierType;
  defaultOption: string;
  confidence: number;
  hasException: boolean;
  notes?: string;
  cabin: string;
}

export const mockCohortPassengers: CohortPassenger[] = [
  { pnr: 'ABCDE1', name: 'Sarah Mitchell', tier: 'Diamond', defaultOption: 'A', confidence: 92, hasException: false, cabin: 'J' },
  { pnr: 'FGHIJ2', name: 'James Chen', tier: 'Diamond', defaultOption: 'A', confidence: 89, hasException: false, cabin: 'J' },
  { pnr: 'KLMNO3', name: 'Emma Watson', tier: 'Gold', defaultOption: 'B', confidence: 85, hasException: false, cabin: 'W' },
  { pnr: 'PQRST4', name: 'Michael Brown', tier: 'Gold', defaultOption: 'A', confidence: 78, hasException: true, notes: 'Infant', cabin: 'J' },
  { pnr: 'UVWXY5', name: 'Lisa Anderson', tier: 'Silver', defaultOption: 'B', confidence: 82, hasException: false, cabin: 'W' },
  { pnr: 'ZABCD6', name: 'David Kim', tier: 'Silver', defaultOption: 'C', confidence: 74, hasException: false, cabin: 'Y' },
  { pnr: 'EFGHI7', name: 'Sophie Turner', tier: 'Green', defaultOption: 'C', confidence: 88, hasException: false, cabin: 'Y' },
  { pnr: 'JKLMN8', name: 'Robert Lee', tier: 'Green', defaultOption: 'C', confidence: 90, hasException: false, cabin: 'Y' },
  { pnr: 'OPQRS9', name: 'Maria Garcia', tier: 'Diamond', defaultOption: 'A', confidence: 94, hasException: false, cabin: 'F' },
  { pnr: 'TUVWX0', name: 'John Smith', tier: 'Gold', defaultOption: 'B', confidence: 71, hasException: true, notes: 'PRM', cabin: 'W' },
];
